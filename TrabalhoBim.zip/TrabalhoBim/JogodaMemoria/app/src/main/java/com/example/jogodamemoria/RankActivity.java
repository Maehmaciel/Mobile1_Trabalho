package com.example.jogodamemoria;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class RankActivity extends AppCompatActivity {
    private ListView listView;
    private ArrayList<ItemJogo> dados;
    private Adapter adapter;
    String jogador="";
    private TextView nomeJogador;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rank);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        adapter= new Adapter(getApplicationContext(),dados);
        listView=findViewById(R.id.listview);
        Intent intent = getIntent();
        jogador = intent.getStringExtra("jogador");
        nomeJogador=findViewById(R.id.jogadorRank);
        nomeJogador.setText(jogador);
        criarLista();


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            SharedPreferences sharedPref = getSharedPreferences("pref", Context.MODE_PRIVATE);
                String data =  dados.get(position).toString()+"_";
                if(sharedPref.contains(jogador)){
                    data+=sharedPref.getString(jogador,"_vazio_");
                }
                SharedPreferences.Editor editor = getSharedPreferences("pref", MODE_PRIVATE).edit();
                editor.putString(jogador, data);

                boolean resposta = editor.commit();

                if(resposta){
                    Toast.makeText(getApplicationContext(),"Informação salva", Toast.LENGTH_SHORT).show();
                }
            }
        });
        listView.setAdapter(new Adapter(getApplicationContext(),dados));

    }

    private void criarLista() {
        Intent intent = getIntent();
        String message = intent.getStringExtra("dados");

        SharedPreferences sharedPref = getSharedPreferences("pref", Context.MODE_PRIVATE);

        dados = new ArrayList<>();
        if(sharedPref.contains(jogador)){
            String[] todos = sharedPref.getString(jogador,"_vazio_").split("_");
            for(String t : todos){
                String[] itens= t.split(",");
                try {
                    dados.add(new ItemJogo(Integer.parseInt(itens[0].trim()),Integer.parseInt(itens[1].trim()),Integer.parseInt(itens[2].trim())));
                }catch (NumberFormatException ex){

                }

            }

        }
        if(intent.hasExtra("dados")){
            dados.add(new ItemJogo(dados.size()+1,Integer.parseInt(message.split(",")[1]),Integer.parseInt(message.split(",")[2])));
        }



    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_toolbar, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()) {
            case R.id.sair:
                AlertDialog alertDialog = new AlertDialog.Builder(RankActivity.this).create();
                alertDialog.setTitle("Sair");
                alertDialog.setMessage("Tem certeza que deseja sair?");
                alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Não",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Sim",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                finishAffinity();
                            }
                        });
                alertDialog.show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }


}


