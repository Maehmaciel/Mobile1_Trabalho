package com.example.jogodamemoria;

public class ItemJogo {
    private int jogada,acertos,erros;
    public ItemJogo(int jogada, int acertos, int erros) {
        this.jogada = jogada;
        this.acertos = acertos;
        this.erros = erros;
    }

    public int getJogada() {
        return jogada;
    }

    public int getAcertos() {
        return acertos;
    }

    public int getErros() {
        return erros;
    }

    @Override
    public String toString() {
        return jogada +
                "," + acertos +
                "," + erros;
    }
}