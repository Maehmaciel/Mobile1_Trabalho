package com.example.jogodamemoria;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
public class Adapter extends BaseAdapter {
    private Context context;
    private ArrayList<ItemJogo> dados;

    public Adapter(Context context, ArrayList<ItemJogo> dados) {
        this.context = context;
        this.dados = dados;
    }

    @Override
    public int getCount() {
        return dados.size();
    }

    @Override
    public ItemJogo getItem(int i) {
        return dados.get(i);
    }

    @Override
    public long getItemId(int i ){
        return i;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(context);;
        View minhaView = layoutInflater.inflate(R.layout.item_list,parent,false);
        ItemJogo itemJogo = dados.get(position);
        TextView textViewDesc= minhaView.findViewById(R.id.textViewJogada);
        textViewDesc.setText("Jogada: "+itemJogo.getJogada());

        TextView textViewPreco= minhaView.findViewById(R.id.textViewAcertos);
        textViewPreco.setText("Acertos: "+itemJogo.getAcertos());

        TextView textViewErros= minhaView.findViewById(R.id.textViewErros);
        textViewErros.setText("Erros: "+itemJogo.getErros());


        return minhaView;
    }
}