package com.example.jogodamemoria;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.LayoutTransition;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class ColorActivity extends AppCompatActivity {
    private ViewGroup containerView,root;
    ArrayList<Integer> listaCores, listaEdt;
    String jogador;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_color);
        containerView = findViewById(R.id.container);
        root= findViewById(R.id.root);
        listaCores = new ArrayList();
        listaEdt  = new ArrayList();
        Intent intent = getIntent();
        jogador=intent.getStringExtra("jogador");
    }

    @Override
    protected void onStart() {
        super.onStart();
        new Handler().postDelayed(new Runnable() {
            public void run() {
                addView();
            }
        }, 1000);

    }

    public void addView() {
        for(int i=0;i<9;i++){
            TextView newView  =  new TextView(this);
            Random rnd = new Random();
            int color = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256));
            listaCores.add(color);
            newView.setBackgroundColor(color);
            newView.setLayoutParams(new ViewGroup.LayoutParams(200,200));
            newView.setText(Integer.toString(i+1));
            newView.setTextColor(Color.WHITE);
            newView.setGravity(Gravity.CENTER);
            containerView.addView(newView, i);

        }

        new Handler().postDelayed(new Runnable() {
            public void run() {
                removeAll();
                addInput();
            }
        }, 5000);
    }

    public void addInput() {

        LinearLayout linearLayout = new LinearLayout(this);
        setContentView(linearLayout);
        linearLayout.setOrientation(LinearLayout.VERTICAL);

        for (int i : listaCores){
            listaEdt.add(i);
        }
        Collections.shuffle(listaCores);
        for( int i = 0; i < 9; i++ )
        {
            LinearLayout linearLayout2 = new LinearLayout(this);
            linearLayout2.setOrientation(LinearLayout.HORIZONTAL);
            linearLayout2.setGravity(Gravity.CENTER);
            linearLayout.addView(linearLayout2);
            View newView  =  new View(this);
            newView.setLayoutParams(new ViewGroup.LayoutParams(50,50));
            newView.setBackgroundColor(listaCores.get(i));
            linearLayout2.addView(newView);
            EditText edtText = new EditText(this);
            edtText.setId(listaCores.get(i));

            edtText.setHint("Posição:");
            linearLayout2.addView(edtText);

        }
        Button btn = new Button(this);
        btn.setText("Finalizar Jogada");
        btn.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                finalizarJogada();
            }
        });

        linearLayout.addView(btn);
    }

    private void finalizarJogada(){
        int pontuacao=0;

        for( int i : listaCores)
        {
            EditText edt = findViewById(i);
            try {
                int posicao = Integer.parseInt(edt.getText().toString()) -1;
                if(listaEdt.get(posicao)==i)
                    pontuacao++;
                //Toast.makeText(getApplicationContext(),"Informado:"+listaEdt.get(posicao).toString()+" era"+i,Toast.LENGTH_SHORT).show();
            }catch (NumberFormatException ex){

            }
        }
        Intent intent = new Intent(this, RankActivity.class);
        int erros=9-pontuacao;
        intent.putExtra("dados", jogador+","+pontuacao+","+Integer.toString(erros));
        intent.putExtra("jogador", jogador);
        startActivity(intent);
        finish();
    }

    private void removeAll() {

            containerView.removeAllViews();

    }

}
