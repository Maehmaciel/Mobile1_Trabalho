package com.example.jogodamemoria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity{
    private TextView txtNome;
    private RadioButton jogarCores, jogarNumeros;
    private int tipoJogo;
    private ProgressBar progressBar;
    String message;
    int i =0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        txtNome = findViewById(R.id.txtNome);
        jogarCores=findViewById(R.id.itemCores);
        jogarNumeros=findViewById(R.id.itemNumeros);
        Intent intent = getIntent();
        message = intent.getStringExtra("jogador");
        progressBar = findViewById(R.id.progressBar);
        txtNome.setText("Olá, "+message);
    }


    public void jogar(View v){
        Intent intent = null;

        if (jogarCores.isChecked())
            intent = new Intent(this, ColorActivity.class);
        else if (jogarNumeros.isChecked())
            intent = new Intent(this, NumberActivity.class);
        else
            Toast.makeText(getApplicationContext(),"Selecione um tipo de jogo",Toast.LENGTH_SHORT).show();

        if(intent!=null){
            intent.putExtra("jogador", message);
            startActivity(intent);
        }

    }

    public void ranking(View v){

        executarProgress();
    }
    private void redirecionarRank(){
        Intent intent = new Intent(this, RankActivity.class);
        intent.putExtra("jogador", message);
        startActivity(intent);
        finish();
    }
    private void executarProgress(){

        final Handler handler = new Handler();
        progressBar.setVisibility(View.VISIBLE);
        i = progressBar.getProgress();
        Intent intent = new Intent(this, RankActivity.class);
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (i<100){
                    i=i+10;
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            progressBar.setProgress(i);
                            if(i>=100){
                                redirecionarRank();
                            }
                        }
                    });

                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException ex) {
                        System.out.println(ex.getMessage());

                    }

                }
            }
        }).start();
    }
}
