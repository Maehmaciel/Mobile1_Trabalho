package com.example.jogodamemoria;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;


import java.util.ArrayList;
import java.util.Random;

public class NumberActivity extends AppCompatActivity {
    private ViewGroup root;
    private LinearLayout containerView;
    private ArrayList<Integer> lista;
    private EditText qtd;
    int qtdNumeros=0;
    int pontuacao=0;
    String jogador="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_number);
        containerView = findViewById(R.id.container);
        root= findViewById(R.id.root);
        qtd=findViewById(R.id.qtd);
        lista = new ArrayList();
        Intent intent = getIntent();
        jogador=intent.getStringExtra("jogador");
    }


    public void iniciarJogo(View v){

        qtdNumeros =Integer.parseInt(qtd.getText().toString());
        qtd.setVisibility(View.GONE);
        v.setVisibility(View.GONE);
        removeAll();

        addView();

    }

    public void addView() {


        for(int i=0;i<qtdNumeros;i++){
            TextView newView  =  new TextView(this);
            
            Random rnd = new Random();
            int item = rnd.nextInt(256);
            lista.add(item);
            newView.setText(Integer.toString(item)+", ");
            containerView.addView(newView, i);

        }

        new Handler().postDelayed(new Runnable() {
            public void run() {
                removeAll();
                addInput();
            }
        }, 5000);
    }

    public void addInput() {

        LinearLayout linearLayout = new LinearLayout(this);
        setContentView(linearLayout);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        final EditText edtText = new EditText(this);
        Button btn = new Button(this);
        edtText.setHint("Digite os itens mostrados, EX: 30,70,40:");
        btn.setText("Finalizar Jogada");
        btn.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {


                finalizarJogada(edtText.getText().toString());
            }
        });

        linearLayout.addView(edtText);
        linearLayout.addView(btn);
    }

    private void finalizarJogada(String resposta){
        String itens[]=resposta.split(",");
        for(String item:itens){
            try {
                int possivelResposta=Integer.parseInt(item.trim());

                if(lista.indexOf(possivelResposta)!=-1)
                    pontuacao++;

            }catch (NumberFormatException ex){
                //Não era um número
            }

        }

        Intent intent = new Intent(this, RankActivity.class);
        intent.putExtra("jogador", jogador);
        int erros=qtdNumeros-pontuacao;
        intent.putExtra("dados", jogador+","+pontuacao+","+Integer.toString(erros));
        startActivity(intent);
        finish();
    }

    private void removeAll() {

        containerView.removeAllViews();

    }
}
